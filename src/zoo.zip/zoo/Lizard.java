package zoo;

public class Lizard	extends Reptile {

	public Lizard(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

}
