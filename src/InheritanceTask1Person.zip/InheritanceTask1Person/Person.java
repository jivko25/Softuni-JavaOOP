package InheritanceTask1Person;

public abstract class Person {
	private String name;
	private int age;
	public abstract String getName();
	public abstract int getAge();
}
